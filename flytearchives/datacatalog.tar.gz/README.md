# datacatalog
Service that catalogs data to allow for data discovery, lineage and tagging
